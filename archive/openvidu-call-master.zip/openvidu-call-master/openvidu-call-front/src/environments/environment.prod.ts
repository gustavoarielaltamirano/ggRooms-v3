export const environment = {
  production: true,
  openvidu_url: '',
  openvidu_secret: ''
};
