export enum VideoSizeIcon {
	BIG = 'zoom_in',
	NORMAL = 'zoom_out'
}

export enum VideoFullscreenIcon {
	BIG = 'fullscreen',
	NORMAL = 'fullscreen_exit'
}
