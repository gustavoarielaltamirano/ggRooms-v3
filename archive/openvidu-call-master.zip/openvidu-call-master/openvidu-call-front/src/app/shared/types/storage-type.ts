export enum Storage{
	USER_NICKNAME = 'openviduCallNickname',
	VIDEO_DEVICE = 'openviduCallVideoDevice',
	AUDIO_DEVICE = 'openviduCallAudioDevice'
}