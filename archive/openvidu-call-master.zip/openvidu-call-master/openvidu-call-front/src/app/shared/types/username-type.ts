
export interface UserName {
	nickname: string;
	connectionId: string;
}