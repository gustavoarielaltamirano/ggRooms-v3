export enum Signal {
	NICKNAME_CHANGED = 'nicknameChanged',

}