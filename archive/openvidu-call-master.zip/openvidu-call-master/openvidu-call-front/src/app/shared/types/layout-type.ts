export enum LayoutType {
	ROOT_CLASS = 'OT_root',
}

export enum LayoutClass {
	BIG_ELEMENT = 'OV_big',
	SMALL_ELEMENT = 'OV_small',
}
