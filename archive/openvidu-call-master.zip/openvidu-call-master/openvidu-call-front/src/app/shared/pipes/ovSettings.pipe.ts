import { Pipe, PipeTransform } from '@angular/core';
import { OvSettingsModel } from '../models/ovSettings';

@Pipe({ name: 'hasChat', pure: true })
export class HasChatPipe implements PipeTransform {
	constructor() {}
	transform(ovSettings: OvSettingsModel): boolean {
		return !ovSettings || ovSettings.hasChat();
	}
}

@Pipe({ name: 'hasAudio', pure: true })
export class HasAudioPipe implements PipeTransform {
	constructor() {}
	transform(ovSettings: OvSettingsModel): boolean {
		return !ovSettings || ovSettings.hasAudio();
	}
}

@Pipe({ name: 'hasVideo', pure: true })
export class HasVideoPipe implements PipeTransform {
	constructor() {}
	transform(ovSettings: OvSettingsModel): boolean {
		return !ovSettings || ovSettings.hasVideo();
	}
}

@Pipe({ name: 'isAutoPublish', pure: true })
export class IsAutoPublishPipe implements PipeTransform {
	constructor() {}
	transform(ovSettings: OvSettingsModel): boolean {
		return !ovSettings || ovSettings.isAutoPublish();
	}
}

@Pipe({ name: 'hasScreenSharing', pure: true })
export class HasScreenSharingPipe implements PipeTransform {
	constructor() {}
	transform(ovSettings: OvSettingsModel): boolean {
		return !ovSettings || ovSettings.hasScreenSharing();
	}
}

@Pipe({ name: 'hasFullscreen', pure: true })
export class HasFullscreenPipe implements PipeTransform {
	constructor() {}
	transform(ovSettings: OvSettingsModel): boolean {
		return !ovSettings || ovSettings.hasFullscreen();
	}
}

@Pipe({ name: 'hasLayoutSpeaking', pure: true })
export class HasLayoutSpeakingPipe implements PipeTransform {
	constructor() {}
	transform(ovSettings: OvSettingsModel): boolean {
		return !ovSettings || ovSettings.hasLayoutSpeaking();
	}
}

@Pipe({ name: 'hasExit', pure: true })
export class HasExitPipe implements PipeTransform {
	constructor() {}
	transform(ovSettings: OvSettingsModel): boolean {
		return !ovSettings || ovSettings.hasExit();
	}
}
